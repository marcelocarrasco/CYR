#!/bin/bash

sh /home/oracle/Pentaho/data-integration/kitchen.sh -file=/home/oracle/CYR/PentahoSourceFiles/GetStatusGral.kjb
